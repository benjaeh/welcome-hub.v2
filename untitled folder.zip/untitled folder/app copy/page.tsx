'use client';

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  MapPin, Bus, BookOpen, Users, HeartHandshake, ShieldCheck, PhoneCall, Building2,
  Search, Megaphone, QrCode, ClipboardList, Info, LifeBuoy, ChevronRight, Mailbox, CalendarDays, Sun, Moon, Globe
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import Image from "next/image";
import { LANGS, RTL_LANGS, t, type Lang } from "./i18n";


/** ---- Helpers ---- */
function useLocalTime() {
  const [now, setNow] = React.useState(new Date());
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}
type SectionCardProps = {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  children?: React.ReactNode;
  onClick?: () => void;
  href?: string;
};
const SectionCard: React.FC<SectionCardProps> = ({ title, icon: Icon, children, onClick, href }) => {
  const body = (
    <Card className="hover:shadow-xl transition-shadow cursor-pointer rounded-2xl h-full">
      <CardContent className="p-5 flex gap-4 items-start">
        <div className="p-3 rounded-2xl bg-muted shrink-0"><Icon className="w-7 h-7" /></div>
        <div className="space-y-1">
          <h3 className="text-lg font-semibold leading-tight">{title}</h3>
          <div className="text-sm text-muted-foreground">{children}</div>
        </div>
        <ChevronRight className="w-5 h-5 ml-auto mt-1 text-muted-foreground" />
      </CardContent>
    </Card>
  );
  if (href) return <a href={href} target="_blank" rel="noreferrer" className="block h-full">{body}</a>;
  return <button className="w-full text-left h-full" onClick={onClick}>{body}</button>;
};

const PillButton: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement>> = ({ children, ...props }) => (
  <button {...props} className={`px-4 py-2 rounded-full bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 active:opacity-80 transition ${props.className ?? ""}`}>{children}</button>
);

// Temporary demo announcements
const DEMO_ANNOUNCEMENTS = [
  { id: 1, text: "Free lunch today at 12 PM in Room 105!" },
  { id: 2, text: "Airport pickups running from Stand B – ask a volunteer." },
  { id: 3, text: "Opal card help desk open 10 AM – 4 PM." },
];


/** ---- Component ---- */
export default function App() {
const [lang, setLang] = React.useState<Lang>("en");
React.useEffect(() => {
  const saved = localStorage.getItem("hub.lang") as Lang | null;
  if (saved) setLang(saved);
}, []);
React.useEffect(() => {
  localStorage.setItem("hub.lang", lang);
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL_LANGS.includes(lang) ? "rtl" : "ltr";
}, [lang]);

  const [highContrast, setHighContrast] = React.useState(false);
  const [largeText, setLargeText] = React.useState(false);
  const [dark, setDark] = React.useState(false);

  const now = useLocalTime();
  const dateStr = new Date().toLocaleString(undefined, { dateStyle: "full", timeStyle: "short" });
  const RTL_LANGS = ["ar"];

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  React.useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = RTL_LANGS.includes(lang) ? "rtl" : "ltr";
  }, [lang]);
  // ⬇️ …a partir de aquí continúa tu JSX (header, hero, grids, etc.)


  return (
  <div className={`${highContrast ? "contrast-more" : ""} ${largeText ? "text-[1.1rem]" : ""} min-h-screen bg-background text-foreground`}>
      {/* Top Bar */}
    <header className="w-full bg-white shadow-sm">
  <div className="max-w-6xl mx-auto flex justify-center py-3">
    <img
      src="/communiteer.png"
      alt="Communiteer Logo"
      className="h-15 w-auto"
    />
  </div>
</header>


      <div className="flex items-center gap-3">
  <select
    value={lang}
    onChange={(e) => setLang(e.target.value as Lang)}
    className="border rounded-xl px-3 py-2 text-sm bg-background"
    aria-label="Language selector"
  >
    {LANGS.map(l => (
      <option key={l.code} value={l.code}>{l.label}</option>
    ))}
  </select>
</div>
      {/* Welcome Hero */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 rounded-3xl">
            <CardContent className="p-6 lg:p-8">
              <div className="flex flex-col lg:flex-row lg:items-center gap-6">
                <img src="https://images.unsplash.com/photo-1558021211-6d1403321394?q=80&w=1200&auto=format&fit=crop" alt="Friendly student ambassadors" className="rounded-3xl w-full lg:w-1/2 object-cover aspect-video" />
                <div className="flex-1 space-y-3">
                  <h1 className="text-3xl md:text-4xl font-bold leading-tight">Welcome to the International Student Hub!</h1>
                  <p className="text-muted-foreground">Quickly check in, find your way around, and explore support, volunteering and life in NSW—all in one place.</p>
                  <div className="flex flex-wrap gap-3">
                    <PillButton onClick={() => document.getElementById("searchBox")?.focus()}><Search className="inline w-4 h-4 mr-2"/>Search</PillButton>
                    <Dialog>
                      <DialogTrigger asChild>
                        <PillButton><QrCode className="inline w-4 h-4 mr-2"/>Show Check‑In QR</PillButton>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[440px]">
                        <DialogHeader>
                          <DialogTitle>Scan to Check‑In</DialogTitle>
                          <DialogDescription>Use your phone’s camera to open the registration form.</DialogDescription>
                        </DialogHeader>
                        <div className="flex justify-center py-4">
                          <QRCodeSVG value="https://example.org/check-in" size={256} includeMargin />
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl">
            <CardContent className="p-6 space-y-3">
              <div className="flex items-center gap-2"><CalendarDays className="w-5 h-5"/><span className="font-semibold">Local time & date</span></div>
              <div className="text-2xl font-bold">{dateStr}</div>
              <Separator />
              <div className="flex items-center gap-2"><Megaphone className="w-5 h-5"/><span className="font-semibold">Announcements</span></div>
              <div className="space-y-2">
                {DEMO_ANNOUNCEMENTS.map(a => (
                  <Alert key={a.id} className="rounded-xl">
                    <AlertTitle>Update</AlertTitle>
                    <AlertDescription>{a.text}</AlertDescription>
                  </Alert>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Search */}
      <div className="max-w-6xl mx-auto px-4 pb-2">
        <div className="flex items-center gap-3">
          <Input id="searchBox" placeholder="Search the Hub (e.g. ‘TFN’, ‘campus map’, ‘OSHC’)" className="rounded-2xl py-6 text-base" />
          <Button className="rounded-2xl px-6 h-12 text-base"><Search className="w-5 h-5 mr-2"/>Search</Button>
        </div>
      </div>

{/* Main Grid */}
<main className="max-w-6xl mx-auto px-4 py-6">
  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
    {/* MVP 1. Check-In / Register */}
    <SectionCard
      title="Check-In / Register"
      icon={ClipboardList}
      onClick={() => window.open("https://example.org/check-in", "_blank")}
    >
      Scan the QR to confirm your arrival.
    </SectionCard>

    {/* MVP 2. Welcome Guide */}
    <SectionCard
      title="Welcome Guide"
      icon={BookOpen}
      href="https://example.org/welcome-guide"
    >
      Key contacts, emergency info and quick tips for settling in.
    </SectionCard>

    {/* MVP 3. About Study NSW */}
    <SectionCard
      title="About Study NSW"
      icon={Info}
      href="https://www.study.nsw.gov.au/"
    >
      Brief overview and programs. 24/7 Support Line: <strong>1300 36 78 99</strong>.
    </SectionCard>

    {/* MVP 4. About Communiteer */}
    <SectionCard
      title="About Communiteer"
      icon={HeartHandshake}
      href="https://communiteer.org/"
    >
      Purpose-driven volunteering and community opportunities.
    </SectionCard>

    {/* MVP 5. Ask for Help */}
    <SectionCard
      title="Ask for Help"
      icon={LifeBuoy}
      onClick={() => window.open("mailto:support@example.org", "_blank")}
    >
      Tap to contact the support team or request a callback.
    </SectionCard>

    {/* MVP 6. Subscribe to Newsletter (QR) */}
    <Dialog>
      <DialogTrigger asChild>
        <button className="w-full text-left h-full">
          <Card className="hover:shadow-xl transition-shadow cursor-pointer rounded-2xl h-full">
            <CardContent className="p-5 flex gap-4 items-start">
              <div className="p-3 rounded-2xl bg-muted shrink-0">
                <Mailbox className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-semibold leading-tight">
                  Subscribe to Communiteer Newsletter
                </h3>
                <div className="text-sm text-muted-foreground">
                  Scan the QR to sign up quickly.
                </div>
              </div>
              <ChevronRight className="w-5 h-5 ml-auto mt-1 text-muted-foreground" />
            </CardContent>
          </Card>
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[440px]">
        <DialogHeader>
          <DialogTitle>Subscribe via QR</DialogTitle>
          <DialogDescription>
            Use your phone to open the subscription page.
          </DialogDescription>
        </DialogHeader>
        <div className="flex justify-center py-4">
          <QRCodeSVG value="https://communiteer.org/newsletter" size={256} includeMargin />
        </div>
      </DialogContent>
    </Dialog>
  </div>


<div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
  {/* Quick Help tile retained in MVP */}
  <Card className="rounded-2xl">
    <CardContent className="p-6 space-y-4">
      <div className="flex items-center gap-2">
        <LifeBuoy className="w-5 h-5" />
        <h3 className="font-semibold">Need help now?</h3>
      </div>
      <div className="space-y-3">
        <Button
          className="w-full rounded-xl"
          onClick={() => window.open("tel:1300367899", "_self")}
        >
          <PhoneCall className="w-5 h-5 mr-2" />
          Call Study NSW 24/7: 1300 36 78 99
        </Button>
        <Button
          variant="outline"
          className="w-full rounded-xl"
          onClick={() => window.open("mailto:support@example.org", "_blank")}
        >
          Email Support Team
        </Button>
      </div>
    </CardContent>
  </Card>
</div>

      </main>

      <footer className="max-w-6xl mx-auto px-4 py-8 text-sm text-muted-foreground">
        <Separator className="mb-4" />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Badge variant="secondary">iPad kiosk</Badge>
            <span>Built as a lightweight web app prototype.</span>
          </div>
          <div className="flex items-center gap-3">
            <a className="underline" href="https://www.study.nsw.gov.au/" target="_blank" rel="noreferrer">study.nsw.gov.au</a>
            <span>•</span>
            <a className="underline" href="https://communiteer.org/" target="_blank" rel="noreferrer">communiteer.org</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
